<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=membres;charset=utf8", "root", "");
if(isset($_GET['id']) AND !empty($_GET['id'])) {
   $get_id = htmlspecialchars($_GET['id']);
   $article = $bdd->prepare('SELECT * FROM articles WHERE id = ?');
   $article->execute(array($get_id));
   if($article->rowCount() == 1) {
      $article = $article->fetch();
      $titre = $article['nom'];
      $prix = $article['prix'];
      $contenu = $article['description'];
   } else {
      die('Cet article n\'existe pas !');
   }
} else {
   die('Erreur');
}
?>
<!DOCTYPE html>
<html>
<head>
   <title>Liste des articles - LaDalle</title>
   <meta charset="utf-8">
   <link rel="stylesheet" type="text/css" href="css/styleacc.css"/>
</head>
  <nav>
   <label for="menu-mobile" class="menu-mobile">Menu</label>
   <input type="checkbox" id="menu-mobile" role="button">
     <ul>
       <li class="menu1"><img class="" src="" alt="" /><a href="index.html">Accueil</a>
       <li class="menu1"><img src="" alt=""/><a href="register.php">Register</a></li>
       <li class="menu1"><img src="" alt=""/><a href="connexion.php">Login</a ></li>
         <li class="menu1"><img src="" alt=""/><a href="listArticle.php">Article</a></li>
         <li class="menu1"><img src="" alt=""/><a href="information.html">Informations</a></li>
     </ul>
  </nav>
  <body>
    <div class="contener">
      <table>
        <h1><?= $titre ?></h1>
        <p>Prix : <?= $prix ?>€</p>
        <p>Descritpion du produit : <?= $contenu ?></p>
      </table>
    </div>
  <footer>
    <p>LaDalle © 2020</p>
  </footer>
</body>
</html>
