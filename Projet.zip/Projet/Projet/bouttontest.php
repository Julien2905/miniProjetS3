
<!DOCTYPE html>
<html>
   <head>
      <title>Titre du document</title>
   </head>
   <body>
      <button onclick="window.location.href = 'ajoutarticle.php';">Cliquez Ici</button>
   </body>
</html>
