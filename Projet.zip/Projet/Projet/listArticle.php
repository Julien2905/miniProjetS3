<?php
$bdd = new PDO("mysql:host=127.0.0.1;dbname=membres;charset=utf8", "root", "");
$articles = $bdd->query('SELECT * FROM articles');
?>
<!DOCTYPE html>
<html>
<head>
   <title>LaDalle</title>
   <meta charset="utf-8">
   <link rel="stylesheet" type="text/css" href="css/styleacc.css"/>
</head>
<nav>
 <label for="menu-mobile" class="menu-mobile">Menu</label>
 <input type="checkbox" id="menu-mobile" role="button">
   <ul>
     <li class="menu1"><img class="" src="" alt="" /><a href="index.html">Accueil</a>
     <li class="menu1"><img src="" alt=""/><a href="register.php">Register</a></li>
     <li class="menu1"><img src="" alt=""/><a href="connexion.php">Login</a ></li>
       <li class="menu1"><img src="" alt=""/><a href="listArticle.php">Article</a></li>
       <li class="menu1"><img src="" alt=""/><a href="information.html">Informations</a></li>
   </ul>
</nav>
<body>
  <div class="contener">
    <table>
       <ul>
          <?php while($a = $articles->fetch()) { ?>
          <li><a href="article.php?id=<?= $a['id'] ?>"><?= $a['nom'] ?></a> | <a href="redaction.php?edit=<?= $a['id'] ?>">Modifier</a> | <a href="supprimer.php?id=<?= $a['id'] ?>">Supprimer</a></li>
          <?php } ?>
       <ul>
   </table>
 </div>
<footer>
  <p>LaDalle © 2020</p>
</footer>
</body>
</html>
