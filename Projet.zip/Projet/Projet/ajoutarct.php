<?php
$bdd = new PDO('mysql:host=127.0.0.1;dbname=membres', 'root', '');

if(isset($_POST['forminscription'])) {
 $nom = htmlspecialchars($_POST['nom']);
 $prix = htmlspecialchars($_POST['prix']);
 $des = htmlspecialchars($_POST['des']);
 if(!empty($_POST['nom']) AND !empty($_POST['prix']) AND !empty($_POST['des'])) {
    $nomlength = strlen($nom);
    if($nomlength <= 255) {
      if($deslength <= 750) {
        $insertmbr = $bdd->prepare("INSERT INTO artcicles(nom, prix, description) VALUES(?, ?, ?)");
        $insertmbr->execute(array($nom, $prix, $des));
        $erreur = "Votre article a bien été mis en ligne! <a href=\"connexion.php\">Me connecter</a>";
      } else {
        $erreur = "Votre description est trop longue !";
      }
    } else {
       $erreur = "Votre nom ne doit pas dépasser 255 caractères !";
    }
 } else {
    $erreur = "Tous les champs doivent être complétés !";
 }
}
?>

<html>
 <head>
    <title>LA DALLE</title>
    <meta charset="utf-8">
 </head>
 <body>
    <div align="center">
       <h2>AJOUT D'ARTICLE</h2>
       <br /><br />
       <form method="POST" action="">
          <table>
             <tr>
                <td align="right">
                   <label for="nom">Nom :</label>
                </td>
                <td>
                   <input type="nom" placeholder="Nom de l'article" id="nom" name="nom" value="<?php if(isset($nom)) { echo $nom; } ?>" />
                </td>
             </tr>
             <tr>
                <td align="right">
                   <label for="prix">Prix :</label>
                </td>
                <td>
                   <input type="prix" placeholder="Votre prix" id="prix" name="prix" value="<?php if(isset($prix)) { echo $prix; } ?>" />
                </td>
             </tr>
             <tr>
                <td align="right">
                   <label for="des">Description :</label>
                </td>
                <td>
                   <input type="des" placeholder="Petite description(Max 750 cara)" id="des" name="des" value="<?php if(isset($des)) { echo $des; } ?>" />
                </td>
             </tr>
             <tr>
                <td></td>
                <td align="center">
                   <br />
                   <input type="submit" name="forminscription" value="Je vends!" />
                </td>
             </tr>
          </table>
       </form>
       <?php
       if(isset($erreur)) {
          echo '<font color="red">'.$erreur."</font>";
       }
       ?>
    </div>
 </body>
</html>
