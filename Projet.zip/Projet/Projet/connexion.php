<?php
	session_start();

	$bdd = new PDO('mysql:host=127.0.0.1;dbname=membres', 'root', '');

	if(isset($_POST['formconnexion'])) {
	   $mailconnect = htmlspecialchars($_POST['mailconnect']);
	   $mdpconnect = sha1($_POST['mdpconnect']);
	   if(!empty($mailconnect) AND !empty($mdpconnect)) {
	      $requser = $bdd->prepare("SELECT * FROM membres WHERE mail = ? AND motdepasse = ?");
	      $requser->execute(array($mailconnect, $mdpconnect));
	      $userexist = $requser->rowCount();
	      if($userexist == 1) {
	         $userinfo = $requser->fetch();
	         $_SESSION['id'] = $userinfo['id'];
	         $_SESSION['pseudo'] = $userinfo['pseudo'];
	         $_SESSION['mail'] = $userinfo['mail'];
	         header("Location: profil.php?id=".$_SESSION['id']);
	      } else {
	         $erreur = "Mauvais mail ou mot de passe !";
	      }
	   } else {
	      $erreur = "Tous les champs doivent être complétés !";
	   }
	}
	?>
	<html>
	   <head>
	      <title>LA DALLE</title>
	      <meta charset="utf-8">
        <link rel="stylesheet" type="text/css" href="css/styleacc.css"/>
	   </head>
     <nav>
 			<label for="menu-mobile" class="menu-mobile">Menu</label>
 			<input type="checkbox" id="menu-mobile" role="button">
 				<ul>
 					<li class="menu1"><img class="" src="" alt="" /><a href="index.html">Accueil</a>
 					<li class="menu1"><img src="" alt=""/><a href="register.php">Register</a></li>
 					<li class="menu1"><img src="" alt=""/><a href="connexion.php">Login</a ></li>
						<li class="menu1"><img src="" alt=""/><a href="listArticle.php">Article</a></li>
	          <li class="menu1"><img src="" alt=""/><a href="information.html">Informations</a></li>
 				</ul>
 		</nav>
		<div class="contener">
		<table>
	   	<body>
	      	<div align="center">
		         <h1>Connexion</h1>
		         <br /><br />
		         <form method="POST" action="">
		            <input type="email" name="mailconnect" placeholder="Mail" />
		            <input type="password" name="mdpconnect" placeholder="Mot de passe" />
		            <br /><br />
		            <input type="submit" name="formconnexion" value="Se connecter !" />
		         </form>
		         <?php
		         if(isset($erreur)) {
		            echo '<font color="red">'.$erreur."</font>";
		         }
		         ?>
				 		</table>
					</form>
	      </div>
			</main>
				<footer>
				<p>LaDalle © 2020</p>
			</footer>
	   </body>
	</html>
