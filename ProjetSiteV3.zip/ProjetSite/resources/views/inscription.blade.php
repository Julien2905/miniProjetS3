<!DOCTYPE html>
<p>echo "Bonjour"</p>
