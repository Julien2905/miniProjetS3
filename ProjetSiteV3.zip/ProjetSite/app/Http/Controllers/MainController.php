<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MainController extends Controller
{
    public function acceuil(){
      return view('welcome');
    }

    public function profil(){
      return view('profil');
    }

    public function inscription(){
      return view('inscription');
    }

    public function login(){
        return view('login');
    }
}
