<!DOCTYPE html>
<p>echo "Bonjour"</p>
<?php /**PATH C:\laragon\www\ProjetSite\resources\views/inscription.blade.php ENDPATH**/ ?>